﻿
using System;
using System.Linq;
using System.Xml.Linq;

class Program
{
    static void Main()
    {
        // Tao cay XML theo de bai
        XDocument xml = new XDocument(
            new XElement("bookstore",
                new XElement("book",
                    new XElement("title",
                        new XAttribute("lang", "en"),
                        "Everyday Italian"),
                    new XAttribute("category", "COOKING"),
                    new XElement("author", "Giada De Laurentiis"),
                    new XElement("year", 2005),
                    new XElement("price", 30.00)
                )
            )
        );

        // Xuat file XML
        xml.Save("bookstore.xml");

        Console.WriteLine("Da tao file bookstore.xml");

        XElement root = xml.Root!;

        // Hien thi phan tu goc
        Console.WriteLine("Phan tu goc: " + root.Name);

        // Dem phan tu con truc tiep
        Console.WriteLine("So phan tu con: "
            + root.Elements().Count());

        // Dem phan tu chau
        Console.WriteLine("So phan tu chau: "
            + root.Elements().Elements().Count());

        // Them sach moi
        XElement sachMoi = new XElement("book",
            new XAttribute("category", "PROGRAMMING"),
            new XElement("title",
                new XAttribute("lang", "en"),
                "C# Co Ban"),
            new XElement("author", "Nguyen Van A"),
            new XElement("year", 2025),
            new XElement("price", 25.00)
        );

        root.Add(sachMoi);
        xml.Save("bookstore.xml");

        Console.WriteLine("\nDa them sach moi!");

        // Tim gia thap nhat va cao nhat
        var giaSach = root.Elements("book")
            .Select(b => (double)b.Element("price")!)
            .ToList();

        Console.WriteLine("Gia thap nhat: " + giaSach.Min());
        Console.WriteLine("Gia cao nhat: " + giaSach.Max());

        // In toan bo XML
        Console.WriteLine("\nCay XML:");
        Console.WriteLine(xml);

        Console.ReadKey();
    }
}
